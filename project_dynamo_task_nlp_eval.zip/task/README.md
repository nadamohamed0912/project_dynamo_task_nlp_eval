# Offline NLP Ticket Triage Evaluation Repair

This Harbor task asks an agent to repair and complete an offline NLP evaluation workflow for support-ticket classification. The agent must reconcile noisy raw model outputs, label aliases, duplicate predictions, confidence thresholds, abstentions, and per-class metric rules, then write deterministic result artifacts under `/app/results/`.

The task belongs to Machine Learning and AI / NLP and language models because the central work is evaluating a language-model text classification pipeline rather than generic file processing.
