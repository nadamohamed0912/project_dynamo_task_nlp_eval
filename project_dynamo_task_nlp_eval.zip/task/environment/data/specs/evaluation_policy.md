# Ticket Triage Evaluation Policy

Canonical labels, in report order: `billing`, `technical`, `account_access`, `shipping`, `cancellation`.

Confidence threshold: `0.65`.

Prediction normalization rules:
1. Read gold tickets from `/app/data/tickets.gold.jsonl` and raw model outputs from `/app/data/model_outputs.raw.jsonl`.
2. Use `/app/config/label_aliases.json` to map raw `model_label` values to canonical labels. Matching is case-insensitive after Unicode NFKC normalization and collapsing whitespace. Alias strings are otherwise exact.
3. Ignore raw prediction records whose `ticket_id` is not present in the gold file.
4. If a gold ticket has multiple raw predictions, first parse confidence values, then choose the record with the highest confidence. Missing confidence means `1.0`. Numeric strings such as `"0.82"` are valid. Invalid, negative, or greater-than-one confidence values mean `0.0`. If confidence ties, choose the later record in file order.
5. If the chosen record's label is not a known alias, output an abstention with reason `unknown_label`.
6. If the chosen record's normalized label is known but confidence is below `0.65`, output an abstention with reason `low_confidence`.
7. If a gold ticket has no usable prediction record, output an abstention with reason `missing_prediction`.
8. Otherwise output the canonical label with reason `ok`.

Metrics rules:
- Evaluate all gold tickets.
- Abstentions are incorrect and count as false negatives for the gold class.
- For each class: `tp`, `fp`, `fn`, `precision`, `recall`, and `f1`.
- `accuracy = correct predictions / total gold tickets`, including abstentions as incorrect.
- `coverage = non_abstained predictions / total gold tickets`.
- `macro_f1` is the unweighted mean of the five class F1 values in canonical label order.
- Round all metric floats to six decimal places.
