#!/usr/bin/env python3
"""Intentionally incomplete evaluator for the ticket-triage task.

It is provided as a starting point. It has known bugs: it trusts raw labels,
does not handle duplicates correctly, treats abstentions as skipped rows, and
computes only accuracy. You may repair this file or replace it entirely.
"""
import json
from pathlib import Path

GOLD = Path('/app/data/tickets.gold.jsonl')
RAW = Path('/app/data/model_outputs.raw.jsonl')
OUT = Path('/app/results/evaluation_report.json')


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def main():
    gold = {r['ticket_id']: r['gold_label'] for r in read_jsonl(GOLD)}
    preds = {r['ticket_id']: r.get('model_label') for r in read_jsonl(RAW)}
    correct = sum(1 for tid, label in gold.items() if preds.get(tid) == label)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({'accuracy': correct / len(gold)}, indent=2))


if __name__ == '__main__':
    main()
