#!/usr/bin/env python3
import json
import math
import unicodedata
from collections import Counter, defaultdict, OrderedDict
from pathlib import Path

APP = Path('/app')
GOLD_PATH = APP / 'data/tickets.gold.jsonl'
RAW_PATH = APP / 'data/model_outputs.raw.jsonl'
ALIASES_PATH = APP / 'config/label_aliases.json'
OUT_DIR = APP / 'results'
PRED_OUT = OUT_DIR / 'predictions.normalized.jsonl'
REPORT_OUT = OUT_DIR / 'evaluation_report.json'
LABELS = ['billing', 'technical', 'account_access', 'shipping', 'cancellation']
THRESHOLD = 0.65


def read_jsonl(path: Path):
    rows = []
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def norm_text(value) -> str:
    if value is None:
        return ''
    text = unicodedata.normalize('NFKC', str(value)).casefold().strip()
    return ' '.join(text.split())


def parse_conf(value):
    if value is None:
        return 1.0
    try:
        conf = float(value)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(conf) or conf < 0 or conf > 1:
        return 0.0
    return conf


def round6(x):
    return round(float(x) + 0.0, 6)


def build_alias_map():
    aliases = json.loads(ALIASES_PATH.read_text(encoding='utf-8'))
    out = {}
    for canonical, vals in aliases.items():
        out[norm_text(canonical)] = canonical
        for val in vals:
            out[norm_text(val)] = canonical
    return out


def choose_predictions(raw_rows, gold_ids):
    chosen = {}
    seen_counts = Counter()
    ignored_extra = 0
    for idx, row in enumerate(raw_rows):
        tid = row.get('ticket_id')
        if tid not in gold_ids:
            ignored_extra += 1
            continue
        seen_counts[tid] += 1
        conf = parse_conf(row.get('confidence'))
        candidate = {
            'index': idx,
            'ticket_id': tid,
            'source_label': row.get('model_label'),
            'confidence': conf,
        }
        prev = chosen.get(tid)
        if prev is None or conf > prev['confidence'] or (conf == prev['confidence'] and idx > prev['index']):
            chosen[tid] = candidate
    duplicate_ids = sorted([tid for tid, count in seen_counts.items() if count > 1])
    return chosen, ignored_extra, duplicate_ids


def normalized_predictions(gold_rows, chosen, alias_map):
    results = []
    for gold in sorted(gold_rows, key=lambda r: r['ticket_id']):
        tid = gold['ticket_id']
        cand = chosen.get(tid)
        if cand is None:
            results.append({
                'ticket_id': tid,
                'predicted_label': 'abstain',
                'confidence': None,
                'source_label': None,
                'reason': 'missing_prediction',
            })
            continue
        canonical = alias_map.get(norm_text(cand['source_label']))
        if canonical is None:
            pred, reason = 'abstain', 'unknown_label'
        elif cand['confidence'] < THRESHOLD:
            pred, reason = 'abstain', 'low_confidence'
        else:
            pred, reason = canonical, 'ok'
        results.append({
            'ticket_id': tid,
            'predicted_label': pred,
            'confidence': cand['confidence'],
            'source_label': cand['source_label'],
            'reason': reason,
        })
    return results


def compute_report(gold_rows, preds, ignored_extra, duplicate_ids):
    gold_by_id = {r['ticket_id']: r['gold_label'] for r in gold_rows}
    pred_by_id = {r['ticket_id']: r['predicted_label'] for r in preds}
    total = len(gold_rows)
    abstentions = sum(1 for r in preds if r['predicted_label'] == 'abstain')
    non_abstained = total - abstentions
    correct = sum(1 for tid, gold in gold_by_id.items() if pred_by_id.get(tid) == gold)

    per_class = OrderedDict()
    f1s = []
    for label in LABELS:
        support = sum(1 for g in gold_by_id.values() if g == label)
        tp = sum(1 for tid, gold in gold_by_id.items() if gold == label and pred_by_id.get(tid) == label)
        fp = sum(1 for tid, gold in gold_by_id.items() if gold != label and pred_by_id.get(tid) == label)
        fn = sum(1 for tid, gold in gold_by_id.items() if gold == label and pred_by_id.get(tid) != label)
        precision = 0.0 if tp + fp == 0 else tp / (tp + fp)
        recall = 0.0 if tp + fn == 0 else tp / (tp + fn)
        f1 = 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)
        f1s.append(f1)
        per_class[label] = {
            'support': support,
            'tp': tp,
            'fp': fp,
            'fn': fn,
            'precision': round6(precision),
            'recall': round6(recall),
            'f1': round6(f1),
        }

    return {
        'total': total,
        'coverage': round6(non_abstained / total),
        'accuracy': round6(correct / total),
        'macro_f1': round6(sum(f1s) / len(f1s)),
        'abstentions': abstentions,
        'ignored_extra_predictions': ignored_extra,
        'duplicate_ticket_ids': duplicate_ids,
        'per_class': per_class,
    }


def main():
    gold_rows = read_jsonl(GOLD_PATH)
    raw_rows = read_jsonl(RAW_PATH)
    alias_map = build_alias_map()
    gold_ids = {r['ticket_id'] for r in gold_rows}
    chosen, ignored_extra, duplicate_ids = choose_predictions(raw_rows, gold_ids)
    preds = normalized_predictions(gold_rows, chosen, alias_map)
    report = compute_report(gold_rows, preds, ignored_extra, duplicate_ids)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with PRED_OUT.open('w', encoding='utf-8') as f:
        for row in preds:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=False) + '\n')
    REPORT_OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
